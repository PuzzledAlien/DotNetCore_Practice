﻿namespace Demo.MyJob
{
    public class MyJobConsts
    {
        public const string LocalizationSourceName = "MyJob";

        public const string ConnectionStringName = "Default";
    }
}