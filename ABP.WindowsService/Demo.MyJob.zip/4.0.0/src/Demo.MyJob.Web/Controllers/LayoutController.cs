namespace Demo.MyJob.Web.Controllers
{
    public class LayoutController : MyJobControllerBase
    {

    }
}